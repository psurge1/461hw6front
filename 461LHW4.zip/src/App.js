import './App.css';
import Projects from './Projects';

function App() {
  return <Projects></Projects>
}

export default App;
